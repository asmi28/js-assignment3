/*Question 2:
Write a program which will take OS name and version from the user separated by a space. Then
log the OS name and version on the console.
Input: "Android 9"
Output: The OS name is Android and version is 9*/

let x=prompt("Enter the os name");
let y=prompt("Enter the version");

console.log(`The os name is ${x} and version is ${y}.`);
