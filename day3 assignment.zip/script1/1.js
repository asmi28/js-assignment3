//Question 1:
//Take a number from a user and write a function which checks whether the number is even or
//odd. Assign the result to a variable and log that variable in the console.
//Example Input: 23
//Output: The number entered is 23 and Number is odd

let x=prompt("enter a no");
    if (x%2==0) {
console.log(" No is even");
    }
    else{
        console.log(" No is odd");  
    }
        
    